#ifndef __ROMAN_H__
#define __ROMAN_H__

char* to_roman_numeral(char* dst, int src);

#endif
